#!/bin/bash

flag=1

while [ $flag <> 0 ]
do

echo "-------------------------------------------------"
echo " 1. Add"
echo " 2. Sub"
echo " 3. Mul"
echo " 4. Div"
echo " 0. exit"
echo "-------------------------------------------------"

echo -n "Enter no1 : "
read no1

echo -n "Enter no2 : "
read no2

echo -n "select operation from above menu : "
read flag

if [ $flag == 1 ]
then

echo "Add is : "`expr $no1 + $no2`

elif [ $flag == 2 ]
then

echo "sub is : "`expr $no1 - $no2`

elif [ $flag == 3 ]
then

echo "mul is : "`expr $no1 \* $no2`

elif [ $flag == 4 ]
then

echo "div is : "`expr $no1 \\ $no2`

elif [ $flag == 0 ]
then

exit

elif [ $flag > 5 ]
then

echo "U choosed wrong option please reselect it."
fi

clear

done
