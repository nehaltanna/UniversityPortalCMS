#!/bin/bash

html=$(cat $1 | head -1)
s_html=$(cat $1 | tail -1)

html1=$(echo $html | tr -s '[:upper:]' '[:lower:]')
s_html1=$(echo $s_html | tr -s '[:upper:]' '[:lower:]')

chk1=$(cat $1 | egrep -i '^<html>')
chk2=$(cat $1 | egrep -i '</html>')
chk3=$(cat $1 | egrep -i '<title>')
chk4=$(cat $1 | egrep -i '</title>')
chk5=$(cat $1 | egrep -i '<head>')
chk6=$(cat $1 | egrep -i '</head>')
#  
if [[ $chk1 != "" && $chk2 != "" && $chk4 != "" && $chk3 != "" && $chk5 != "" && $chk6 != "" ]]
then
echo "The file is a html file"
else
echo "The file is not a html file"
fi
