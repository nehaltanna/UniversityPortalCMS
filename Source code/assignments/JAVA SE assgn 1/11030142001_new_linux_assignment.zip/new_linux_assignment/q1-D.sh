#!/bin/bash
# run this script as a root user!!

uname=$(cat /etc/passwd | grep /home | cut -d: -f1)

echo -n "Enter user name :"
read name

if [ $name == $uname ]
then

cd ~

s1=$(cat /etc/passwd | grep /home | cut -d: -f3)-
s2=$(date | cut -c 5-7)-$(date | cut -c 9-10 | tr -d " ")
s3=.ext
s=$s1$s2$s3

mkdir /home/$s

ls | xargs -i cp -r "{}" /home/$s/

cd /home

tar -cvzf $s.tar.gz $s

rm -rf /home/$s

echo 'Backup has been created'

else

echo 'Sorry no such user exist!!'

fi


