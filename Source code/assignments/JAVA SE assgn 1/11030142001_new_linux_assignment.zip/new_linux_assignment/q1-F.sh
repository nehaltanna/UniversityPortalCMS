#!/bin/bash

f=$1
	echo $f
	if [ -f $f ]
	then
	 	echo " - regular file not a directory"
	fi
	if [ -d $f ]
	then
		echo " - sub-direcotry not a file"
	fi
	if [ -r $f ]
	then
		echo " - has a read access"
	fi
	if [ -w $f ]
	then
		echo " - has a write access"
	fi
	if [ -x $f ]
	then
		echo " - has a execute access"
	fi

r=$(cat $1 | egrep -e '^[0-2].[0-5]{0,1}[0-5]{0,1}' | wc -l)
ca=0
cb=0
cc=0
cd=0
ce=0
cat>class_a_ip &
cat>class_b_ip &
cat>class_c_ip &
cat>class_d_ip &
cat>class_e_ip &

for((i=1;i<=$r;i++))
do

no=$(cat $1 | egrep -e '^[0-2].[0-5]{0,1}[0-5]{0,1}' | head -$i | tail -1 | cut -d'.' -f1)
ip=$(cat $1 | egrep -e '^[0-2].[0-5]{0,1}[0-5]{0,1}' | head -$i | tail -1) 

if [[ $no -ge 0 ]] && [[ $no -le 127 ]]
then

echo $ip>>class_a_ip
ca=`expr $ca + 1`

elif [[ $no -ge 128 ]] && [[ $no -le 191 ]]
then

echo $ip>>class_b_ip
cb=`expr $cb + 1`

elif [[ $no -ge 192 ]] && [[ $no -le 223 ]]
then 

echo $ip>>class_c_ip
cc=`expr $cc + 1`

elif [[ $no -ge 224 ]] && [[ $no -le 239 ]]
then 

echo $ip>>class_d_ip
cd=`expr $cd + 1`

else

echo $ip>>lass_e_ip
ce=`expr $ce + 1`

fi

done

echo 'no of class A ip =' $ca
echo 'no of class B ip =' $cb
echo 'no of class C ip =' $cc
echo 'no of class D ip =' $cd
echo 'no of class E ip =' $ce

cat class_a_ip | sort -nu > class_a_ip_sorted
cat class_b_ip | sort -nu > class_b_ip_sorted
cat class_c_ip | sort -nu > class_c_ip_sorted
cat class_d_ip | sort -nu > class_d_ip_sorted
cat class_e_ip | sort -nu > class_e_ip_sorted




