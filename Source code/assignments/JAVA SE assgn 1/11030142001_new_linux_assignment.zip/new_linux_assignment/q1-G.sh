#!/bin/bash

cd $1

len=$(ls | wc -l)
for((i=1;i<=len;i++))
do
f=$(ls | head -$i | tail -1)
	echo $f
	if [ -f $f ]
	then
	 	echo " - regular file not a directory"
	fi
	if [ -d $f ]
	then
		echo " - sub-direcotry not a file"
	fi
	if [ -r $f ]
	then
		echo " - has a read access"
	fi
	if [ -w $f ]
	then
		echo " - has a write access"
	fi
	if [ -x $f ]
	then
		echo " - has a execute access"
	fi
done
